CREATE database NBADASH2;
USE NBADASH2;

-- Now import all CSV files in the zip into NBADASH to follow along with my SQL process. I did this using the import wizard. 

-- DATA CLEANING:
/* The 2021 standings table has confusing column headers that will make it hard to reference. 
This uncleaned table is shown below:
*/
SELECT * FROM 2021standingsOG limit 5;
/* I decided that fixing these column headers would most easily be achieved in excel.
Now using the import wizard, I've imported 2021standings (the cleaned version of the table above) shown below: 
*/
SELECT * FROM 2021standings limit 5;
/* The next step in cleaning 2021standings was to convert the overall and monthly columns (i.e. NOV) to a form we can more easily use;
I made new columns that just contain the number of wins each month:
*/
Drop table if exists `2021standingsclean`;
CREATE TABLE `2021standingsclean` (
  `Rk` int DEFAULT NULL,
  `Team` text,
  `Tm` text,
  `Overall` text,
  `Home_record` text,
  `Road_record` text,
  `Pre_All_Star` text,
  `Post_All_Star` text,
  `Oct` text,
  `Nov` text,
  `Dec` text,
  `Jan` text,
  `Feb` text,
  `Mar` text,
  `Apr` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

alter table 2021standingsclean 
add column Overallw int,
add column Octw int,
add column Novw int,
add column Decw int,
add column Janw int,
add column Febw int,
add column Marw int,
add column Aprw int;

insert into 2021standingsclean (Rk, Team, Tm, Overall, Overallw, `Home_record`, `Road_record`, `Pre_All_Star`,
`Post_All_Star`, Oct, Octw, Nov, Novw, `Dec`, DecW, Jan, Janw, Feb, Febw, Mar, Marw, Apr, Aprw) 
select Rk, Team, Tm, Overall, substring(Overall,1,2), `Home_record`, `Road_record`, `Pre_All_Star`,`Post_All_Star`,
Oct, substring(Oct,1,locate('-',Oct)-1), Nov, substring(Nov,1,locate('-',Nov)-1), `Dec`, substring(`Dec`,1,locate('-',`Dec`)-1), Jan, 
substring(Jan,1,locate('-',Jan)-1), Feb, substring(Feb,1,locate('-',Feb)-1), Mar, substring(Mar,1,locate('-',Mar)-1), 
Apr, substring(Apr,1,locate('-',Apr)-1) from 2021standings;

SELECT * FROM 2021standingsclean limit 5;

/*
Note that 2021playerstats and 2021playeradvancedstats also required some cleaning in excel and SQL. 
Both of these tables had characters in the Player field which weren't UTF-8 characters.
To combat this I filtered to find all records with these characters that couldn't be read in by the SQL import wizard. There were only a few players whose
names contained these characters, so I then manually changed these names (the strange characters were supposed to be apostrophes in nearly all of these cases).

Upon importing 2021playeradvancedstats some minor cleaning was required which I did using the code below:
*/

ALTER TABLE 2021playeradvancedstats
	RENAME COLUMN `ï»¿Rk` to Rk;
SELECT * FROM 2021playeradvancedstats limit 5;


/* The table 2021wins was then created in excel: with the intention of making a discrete line graph in Tableau where
the number of wins by month is displayed. 2021wins was then imported here using the import wizard.
*/
select * from 2021wins limit 5;

-- Now begin EDA to look for insights to include in the Tableau dashboard:

-- Start small, finding some lists of stat leaders that could be useful to display in our dashboard
select Player, PTS from 2021playerstats order by PTS DESC limit 10;
select Player, AST from 2021playerstats order by AST DESC limit 10;
select Player, TRB from 2021playerstats order by TRB DESC limit 10;
select Player, STL from 2021playerstats order by STL DESC limit 10;
select Player, BLK from 2021playerstats order by BLK DESC limit 10;

/* Find the average true shooting % by team. This will be useful going forward as many of the advanced stats,
such as TS%, are neglected in the 2021teamstats table. Note that a tangential goal of this product
is to increase the client's (casual fan's) interest in basketball. To achieve this goal, stats that lead to exciting play
could also be aggregated by team, such as 3 point attempted rate or block percentage. The leaders in these stats could then 
be suggested in the dashboard as teams to watch; and these exciting teams would lead the fan to love basketball nearly as much
as I do.
*/ 
SELECT AVG(`TS%`), Tm from `2021playeradvancedstats` group by Tm order by AVG(`TS%`) DESC; 
SELECT AVG(`BLK%`), Tm from `2021playeradvancedstats` group by Tm order by AVG(`BLK%`) DESC; 
SELECT AVG(3pAr), Tm from `2021playeradvancedstats` group by Tm order by AVG(3pAr) DESC; 

/* Create the toppts procedure by running the topptsproc.sql file included in the zip.
This procedure shows the top 3 players in points per game by team. This information be useful when making our final dashboard, as the
final product could display a similar visualization to this. */
call toppts('LAL');
call toppts('BOS');

/* One final part of our EDA process that might be useful to look into is some of the best defenders in the league,
as evaluated by defensive box plus minus. We can use windows functions to compare these players statistics with
the average of this statistic across their team. Note that we filter for players who played for 30 minutes a game or more
to make sure a player has an adequete sample to base the DBPM stat off of.*/
with CTE2 AS (
select stats.Player, stats.Tm, stats.MP, STL, BLK, DBPM from 
2021playerstats stats join
2021playeradvancedstats adstats
on stats.Player=adstats.Player and stats.Rk=adstats.Rk
where stats.MP>=30
)
Select Player, STL, AVG(STL) OVER(partition by Tm) AS Average_Tm_STL, 
BLK, AVG(BLK) OVER(partition by Tm) AS Average_Tm_BLK,
DBPM
from CTE2 
order by DBPM DESC limit 10; 