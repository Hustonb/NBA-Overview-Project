drop procedure if exists toppts;

DELIMITER //

CREATE PROCEDURE toppts (
	IN teamname VARCHAR(10)
)
BEGIN
with CTE AS (
select stats.Player, stats.Tm, Pts, FGA, `FG%`, `2P%`,`3P%`, `FT%`, `TS%`, OWS, OBPM from 
2021playerstats stats join
2021playeradvancedstats adstats
on stats.Player=adstats.Player and stats.Rk=adstats.Rk
)
SELECT Player, Pts, FGA, `FG%`, `2P%`,`3P%`, `FT%`, `TS%`, OWS, OBPM 
from CTE where Tm=teamname
order by Pts DESC limit 3;

END //

DELIMITER ;